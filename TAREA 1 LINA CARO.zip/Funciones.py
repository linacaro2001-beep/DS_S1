import random
import openpyxl
import matplotlib.pyplot as grafico
# Nombre del archivo de excel -- Estadisticas_juego
FICHERO = r"C:\EjerciciosPython\TAREA 1 LINA CARO\Estadisticas_juego.xlsx"


def menu():
    print("1. Partida modo solitario")
    print("2. Partida 2 jugadores")
    print("3. Estadística")
    print("4. Salir")
    opcion = int(input("Selecciona la partida que deseas jugar: "))
    return (opcion)

def submenu():
    print(" 1. Facil\n 2. Medio\n 3. Dificil")
    dificultad = int(input("Selecciona el nivel de dificultad de la partida: "))
    return (dificultad)


#opcion 1. Modo solitario
def num_aleatorio(minimo, maximo):
    numero = random.randint(minimo, maximo)
    return (numero)

#Opción 2. Modo 2 jugadores
def adivinar():
    while True:
        try:
            numeroJ1 = int(input("JUGADOR 1: Introduce un número a adivinar entre 1 y 1000 (que no lo vea el jugador 2)...: "))
            if 1 <= numeroJ1 <= 1000:
                print("\n" * 50)  # Limpia visualmente la pantalla
                return numeroJ1
            else:
                print("Debe ser un número entre 1 y 1000.")
        except ValueError:
            print("Entrada no válida. Ingresa un número entero.")


#opcion 3. Estadistica

#Creacion del archivo de excel
def inicio_excel():
    archivo_excel = openpyxl.load_workbook(FICHERO)
    if "Resultados" in archivo_excel.sheetnames:
        hoja = archivo_excel["Resultados"]
    else:
        hoja = archivo_excel.create_sheet("Resultados")

    if hoja.max_row == 1 and hoja ["A1"].value is None:
        hoja.append(["Jugador", "Modalidad", "Nivel", "Resultado", "Intentos"])
        
    archivo_excel.save(FICHERO)

#Guardar las partidas
def guardar_estadisticas(nombre, modalidad, nivel, resultado, intentos):
    inicio_excel() #Nos aseguramos que la hoja y encabezados existan
    archivo_excel = openpyxl.load_workbook(FICHERO)
    hoja = archivo_excel ["Resultados"] #Selecciono la hoja de excel que quiero
    
    hoja.append([nombre, modalidad, nivel, resultado, intentos])
    
    archivo_excel.save(FICHERO)
    print(f"Datos guardados: {nombre}, {modalidad}, {nivel}, {resultado}, Intentos: {intentos}")

#Mostrar las estadisticas guardadas
def mostrar_estadisticas():
    inicio_excel() #Nos aseguramos que la hoja y encabezados existan
    archivo_excel = openpyxl.load_workbook(FICHERO)
    hoja = archivo_excel["Resultados"]

    print("\nESTADÍSTICAS DEL JUEGO")
    print("-" * 50)
    
    for fila in hoja.iter_rows(min_row=2, values_only=True):
        print(f"Jugador: {fila[0]} | Modalidad: {fila[1]} | Nivel: {fila[2]} | Resultado: {fila[3]} | Intentos: {fila[4]}")

#Gráfico de partidas ganadas vs perdidas
def grafico_resultados(): 
    inicio_excel()
    archivo_excel = openpyxl.load_workbook(FICHERO)
    hoja = archivo_excel["Resultados"]

    resultados = [] #Lista donde se guardan los datos de los resultados

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        resultados.append(fila[3]) #columna de resultados

    conteo_res = {} #diccionario que cuenta cuantas veces aparece cada resultado
    for r in resultados:
        conteo_res[r] = conteo_res.get(r, 0) + 1

    x = conteo_res.keys()
    y = conteo_res.values()

    grafico.figure() #una nueva figura
    grafico.bar (x, y)
    grafico.title ("Resultados del juego")
    grafico.show()

#Gráfico de las modalidades jugadas
def grafico_modalidades():
    inicio_excel()
    archivo_excel = openpyxl.load_workbook(FICHERO)
    hoja = archivo_excel["Resultados"]

    modalidades = []

    for fila in hoja.iter_rows(min_row=2, values_only=True):
        modalidades.append(fila[1]) #columna de las modalidades

    conteo_mod = {} #diccionario que cuenta cuantas veces aparece cada modalidad
    for m in modalidades:
        conteo_mod[m] = conteo_mod.get(m, 0) + 1

    x = conteo_mod.keys()
    y = conteo_mod.values()

    grafico.figure()
    grafico.bar(x, y)
    grafico.title("Modalidades jugadas")
    grafico.show()
    



    
     
    






                         